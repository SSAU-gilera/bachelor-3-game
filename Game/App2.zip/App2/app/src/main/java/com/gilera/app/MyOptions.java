package com.gilera.app;

import android.content.Context;

public class MyOptions {

    public MyOptions() {
    }

    public void showOptions(Context viewContext, Context mainContext) {
//        AlertDialog.Builder dialogBuilder = new AlertDialog.Builder(viewContext);
//        LayoutInflater inflater = LayoutInflater.from(mainContext);
//        View dialogView = inflater.inflate(R.layout.settings_dialog, null);
//
//        parentConstraintLayout = dialogView.findViewById(R.id.parentConstraintLayout);
//        childConstraintLayout = dialogView.findViewById(R.id.childConstraintLayout);
//
//        switchMusic = dialogView.findViewById(R.id.switch_music);
//        background = dialogView.findViewById(R.id.backgroundImageView);
//        closeOptions = dialogView.findViewById(R.id.closeOptionsImageView);
//        langText = dialogView.findViewById(R.id.text_yazik);
//        musicText = dialogView.findViewById(R.id.text_music);
//        optionsText = dialogView.findViewById(R.id.text_nastroiki);
//
//        dialogBuilder.setView(dialogView);
//        dialogBuilder.show();
    }
}
